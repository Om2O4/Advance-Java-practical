package servlet_p1;
import javax.servlet;
import java.io.IOException;
import java.io.PrintWriter;

public class RegistrationServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // 1. Extract values from the form
        String name = request.getParameter("fullName");
        String email = request.getParameter("email");
        String role = request.getParameter("jobRole");
        String exp = request.getParameter("experience");

        // 2. Set response type
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // 3. Display the values in another page (The "Success" UI)
        out.println("<html><body style='font-family: Arial; padding: 40px;'>");
        out.println("<div style='border: 2px solid #27ae60; padding: 20px; border-radius: 10px;'>");
        out.println("<h2 style='color: #27ae60;'>Registration Successful!</h2>");
        out.println("<p><strong>Candidate Name:</strong> " + name + "</p>");
        out.println("<p><strong>Contact Email:</strong> " + email + "</p>");
        out.println("<p><strong>Applied Position:</strong> " + role + "</p>");
        out.println("<p><strong>Experience:</strong> " + exp + " years</p>");
        out.println("<br><a href='registration.html'>Register Another Candidate</a>");
        out.println("</div></body></html>");
    }
}