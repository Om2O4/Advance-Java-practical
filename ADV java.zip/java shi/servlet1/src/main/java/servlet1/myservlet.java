package servlet1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

// The URL pattern where this servlet will live
@WebServlet("/myservlet")
public class myservlet implements Servlet {

    private ServletConfig config;

    // 1) Called once when the servlet is created 
    @Override
    public void init(ServletConfig config) throws ServletException {
        this.config = config;     
        System.out.println("Servlet (implements Servlet) is Initializing...");
    }

    // 2) Must return the stored ServletConfig
    @Override
    public ServletConfig getServletConfig() {
        return this.config;
    }

    // 3) Called for every request (protocol-agnostic)
    @Override
    public void service(ServletRequest request, ServletResponse response)
            throws ServletException, IOException {

        System.out.println("service() of plain Servlet is handling a request.");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<h1>Hello from the plain Servlet (implements Servlet)!</h1>");
        out.println("<p>The time is: " + new Date() + "</p>");
    }

    // 4) Optional metadata about the servlet
    @Override
    public String getServletInfo() {
        return "MyFirstPlainServlet v1.0 - Demo of Servlet lifecycle by implementing Servlet interface";
    }

    // 5) Called once when the servlet is being destroyed
    @Override
    public void destroy() {
        System.out.println("Servlet (implements Servlet) is being Destroyed. Goodbye!");
    }
}