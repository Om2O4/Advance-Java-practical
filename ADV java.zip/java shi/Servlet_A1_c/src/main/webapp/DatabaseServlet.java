import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/dbOp")
public class dbservlet extends HttpServlet {

    // Database credentials
    private final String url = "jdbc:mysql://localhost:3306/userdb";
    private final String user = "root";
    private final String password = "root";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String operation = request.getParameter("operation"); // insert, update, delete, select
        String name = request.getParameter("name");
        String email = request.getParameter("email");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            // Load Driver and Connect
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, user, password);

            if ("insert".equals(operation)) {
                // CREATE Operation
                PreparedStatement ps = con.prepareStatement("INSERT INTO users(name, email) VALUES(?, ?)");
                ps.setString(1, name);
                ps.setString(2, email);
                ps.executeUpdate();
                out.println("<h3>User Inserted Successfully!</h3>");

            } else if ("update".equals(operation)) {
                // UPDATE Operation
                PreparedStatement ps = con.prepareStatement("UPDATE users SET email=? WHERE name=?");
                ps.setString(1, email);
                ps.setString(2, name);
                ps.executeUpdate();
                out.println("<h3>User Updated Successfully!</h3>");

            } else if ("delete".equals(operation)) {
                // DELETE Operation
                PreparedStatement ps = con.prepareStatement("DELETE FROM users WHERE name=?");
                ps.setString(1, name);
                ps.executeUpdate();
                out.println("<h3>User Deleted Successfully!</h3>");

            } else if ("select".equals(operation)) {
                // READ Operation
                PreparedStatement ps = con.prepareStatement("SELECT * FROM users");
                ResultSet rs = ps.executeQuery();
                out.println("<h3>All Users:</h3>");
                out.println("<table border='1'><tr><th>ID</th><th>Name</th><th>Email</th></tr>");
                while (rs.next()) {
                    out.println("<tr><td>" + rs.getInt("id") + "</td><td>" +
                                rs.getString("name") + "</td><td>" +
                                rs.getString("email") + "</td></tr>");
                }
                out.println("</table>");
            }

            con.close();

        } catch (Exception e) {
            out.println("<h3>Error: " + e.getMessage() + "</h3>");
        }
    }
}