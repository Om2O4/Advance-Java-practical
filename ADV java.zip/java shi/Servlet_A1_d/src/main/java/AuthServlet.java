import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

public class AuthServlet extends HttpServlet {

    @Override
    public void init() throws ServletException {
        // Using Context Interface to set a global application name
        ServletContext context = getServletContext();
        context.setAttribute("appName", "Secure Student Portal v1.0");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String user = request.getParameter("uid");
        String pass = request.getParameter("pwd");

        // Simple Authentication Logic
        if ("admin".equals(user) && "12345".equals(pass)) {
            response.getWriter().println("<h1>Login Successful!</h1>");
            response.getWriter().println("<p>Welcome to: " + getServletContext().getAttribute("appName") + "</p>");
        } else {
            // Triggering Error Handling by throwing an exception or sending an error code
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Invalid Credentials Provided.");
        }
    }
}