import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class LifeCycleServlet extends HttpServlet {

    private int activationCount;

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        activationCount = 0;
        System.out.println("--- LIFE CYCLE: init() called. Servlet initialized. ---");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        activationCount++;
        System.out.println("--- LIFE CYCLE: doGet() called. request #" + activationCount + " ---");
        
        generateResponse(response, "GET Request Received", "The doGet method is typically used for fetching data.");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        activationCount++;
        System.out.println("--- LIFE CYCLE: doPost() called. request #" + activationCount + " ---");
        
        String userData = request.getParameter("userName");
        generateResponse(response, "POST Request Received", "Welcome, " + userData + "! doPost is used for submitting data.");
    }

    private void generateResponse(HttpServletResponse response, String title, String msg) throws IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h2>" + title + "</h2>");
        out.println("<p>" + msg + "</p>");
        out.println("<p>Total requests handled by this instance: " + activationCount + "</p>");
        out.println("<a href='lifecycle.html'>Back to Form</a>");
        out.println("</body></html>");
    }

    @Override
    public void destroy() {
        System.out.println("--- LIFE CYCLE: destroy() called. Resources cleaned up. ---");
        super.destroy();
    }
}